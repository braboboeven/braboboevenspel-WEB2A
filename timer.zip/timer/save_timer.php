<?php
/**
 * Save Timer Data to MySQL Database
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Database config
$db_host = '217.154.166.164';
$db_port = '3306';
$db_user = 'web2a';
$db_pass = '%aXEGd0l91@V<3[i5p$GW';
$db_name = 'web2a'; // default schema name same as user

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON data']);
    exit;
}

if (!isset($data['elapsed_seconds']) || !isset($data['timestamp'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset=utf8mb4";
    $pdo = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Create table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS timer_sessions (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            session_key   VARCHAR(64)  NOT NULL,
            elapsed_seconds INT        NOT NULL,
            duration_seconds INT       NOT NULL DEFAULT 60,
            timestamp     DATETIME     NOT NULL,
            completed     TINYINT(1)   NOT NULL DEFAULT 0,
            ip_address    VARCHAR(45),
            user_agent    TEXT,
            created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    $sessionKey = 'session_' . time() . '_' . uniqid();

    $stmt = $pdo->prepare("
        INSERT INTO timer_sessions
            (session_key, elapsed_seconds, duration_seconds, timestamp, completed, ip_address, user_agent)
        VALUES
            (:session_key, :elapsed_seconds, :duration_seconds, :timestamp, :completed, :ip_address, :user_agent)
    ");

    $stmt->execute([
        ':session_key'      => $sessionKey,
        ':elapsed_seconds'  => (int)$data['elapsed_seconds'],
        ':duration_seconds' => (int)($data['duration_seconds'] ?? 60),
        ':timestamp'        => date('Y-m-d H:i:s', strtotime($data['timestamp'])),
        ':completed'        => (int)($data['completed'] ?? false),
        ':ip_address'       => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ':user_agent'       => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
    ]);

    $insertedId = $pdo->lastInsertId();

    echo json_encode([
        'success'    => true,
        'session_id' => $insertedId,
        'session_key'=> $sessionKey,
        'message'    => 'Timer session saved to MySQL',
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
